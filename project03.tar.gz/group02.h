#ifndef GROUP02_H
#define GROUP02_H

struct Hero {
  int scares;
  int loss;
  int win;
  int items;
};
Hero swang(Hero protagonist);
Hero bcalderon6(Hero protagonist);
Hero kfreeves(Hero protagonist);





#endif

