/* Benny Calderon
CSCI 111 Project03
*/
#include <iostream>
#include "group02.h"
using namespace std;


Hero bcalderon6(Hero protagonist) // I am Benny amd i will be doing 2 rooms inside of this spooky house. The last part is supposed to be hard so we only have one chance 
{
  int scares;
    int count;
    int count2;
    string choice1;
    string choice2;
    string choice3;//starting the variables we need
    cout<<"So now after all you have gone through, you are trying to enter the last two rooms"<<endl<<endl;
    cout<<"Right in front of you is a pitch black room with ominous ambient noise. \n \nYou feel as >>if you know something spooky is going to occur in that room."<<endl<<endl;
    cout<<"This whole time there is a door to the right of you did not even notice. \n \nThere is one ceiling light in that room but it flickers every other second."<<endl<<endl;
    cout<<"Which room are you going to go through? [First or Second] \n "<<endl;
    cin >> choice1;
    if(choice1=="first"|| choice1=="First") // this is the last room and it has the last item you need to win
    {
        cout << "So you have chosen the room down the hall in front of you. \nWhat a man. As you enter the room you see absolutely nothing. \n"<<endl;;
        cout << "Would you like to continue Yes or no ? [1 for yes || 2 for no]"<<endl<<endl;
        cin>>count;
        if (count==1){
       cout<<"Good job, you decided to be brave.\n When you walk in, there is a dresser by you, a broken mirror, and a broken washer.\n"<<endl;
       cout<<"So which will you choose? [Dresser, Mirror, or washer] "<<endl<<endl;;//user gets a choice 
       cin>>choice3;
       
       if (choice3=="dresser"|| choice3=="Dresser"){ //dresser option
        cout <<"So you keep walking you and you hit your leg on a dresser or a wooden table of some sort. \n All you hear is a loud thud, something fell from the dresser. \n"<<endl;
        cout<< "It is a skull from a dead person. \nYou freak out but that was not the only thing that fell. \n"<<endl<<endl;
        cout<< "A flashlight also fell along with the skull." <<endl<<endl;
        cout<< "Will you like to grab the flashlight ? [1 is for yes// 2 is for no]" <<endl<<endl;
        cin>>count2;
            if (count2 == 1){
            cout<<"Way to go you earned the last puzzle to win this game! "<<endl<<endl;
            protagonist.items+=1;
            protagonist.win+=1;
              }
            else{
                cout<<"You chose to not grab it, this will haunt you."<<endl;
                protagonist.scares-=1;
                }
       }
        else if (choice3=="mirror"|| choice3=="Mirror"){ //mirror option
            cout<<"As you are getting closer to the mirror, you notice that is cracked and there is blood on it."<<endl<<endl;
            cout<<"You touch the the blood to see if it is real and realize that it is."<<endl<<endl;
            cout<<"You now look at yourself through the mirror and see that your face is melting away, and you start freaking out and screaming."<<endl<<endl;
            cout<<"You lost a life."<<endl<<endl;
            protagonist.scares-=1;
         }
       
        else if(choice3=="washer"||choice3=="Washer"){ //washer option
            cout<<"You run to the washer because it is on and you are wondering what is in it washing."<<endl<<endl;
            cout<<"You open the washer and realize that it is a doll getting washed."<<endl<<endl;
            cout<<"You grab the doll and you are quick to find out that it is you."<<endl<<endl;
            cout<<"It is a voodoo doll, you have lost a life"<<endl<<endl;
            protagonist.scares-=1;
        }
        }
        else{
            cout<<"So you are not a man of your words. Good luck in life. You lose."<<endl<<endl;
            protagonist.loss+=1;//here amkes it so lose
            
        }
        return protagonist;
        
    }
    else if (choice1=="Second"|| choice1=="second") //this is the other room option
    {
        cout<<"So you have chosen to enter the second room. "<<endl<<endl;
        cout<<"The light in this room  started to flicker more intensely the closer you came inside. "<<endl<<endl;
        cout<<"You keep walking in and you see a broken dresser with one only one drawer,\n a closed closet with shadows moving from underneath the door,\n and a tv with static noises playing."<<endl<<endl;
        cout<< "Which will you choose? [Dresser, Closet, or TV]"<<endl<<endl;
        cin>>choice2;
        if (choice2=="Dresser"|| choice2=="dresser"){ //dresser option and you lose a life
            cout<<"You get closer to the dresser, you open the drawer\n and out comes a bat. The bat startled you, you inspect the drawer and\n you find a bunch of fingers and thumbs. You fainted. (lost a life) "<<endl<<endl;
            protagonist.scares-=1;
        }
        else if (choice2=="Closet"||choice2=="Closet"){ //closet option and you lose a life
            cout<<"You open the door to the closet. While you open it, a ghoul pops out and just rushes you and takes your soul away. So now you are just a flesh corpse. (Lost a life). "<<endl<<endl;
            protagonist.scares-=1;
        }
        else if (choice2=="TV" || choice2=="tv"){ //tv option and you lose a life
            cout<<"The TV is playing static noises, you go and unplug it from the outlet.\n After you unplugged it, the static kept playing but the screen went black.\n So you put your ear closer to the tv and then the tv gave such a high pitch sound that you passed."<<endl<<endl;
            cout<<"You lost a life"<<endl;
            protagonist.scares-=1;

        }
        else{
            cout<<"That is not a right choice, try again"<<endl;
            cin>>choice2; //this sends it back so you can ask
        }
        protagonist.scares-=1;
        return protagonist;
    }
    else{
        cout<<"That is not an option, try again "<<endl;
        cin>>choice1; // sends it back again
    }
   if (scares==0)
   {
     cout <<"You lost" << endl;
   }
    return protagonist;

}



// This is going to be a haunted house with many rooms. 
// after they get scared 5 times its game over
// if they find  candy, flashlight, and a magic wand they win.
// each of us have 2 rooms to make 
// Serena has the wand
// Benny has the flashlight
// Kyle has the candy 


/*if (win==1)
{
    cout<<"Congratulations, you actually won this game! i hope you had fun.\n";
}
if(loss==1)
{
    cout<<"Ha you actually lost, it was so easy. Loser.\n";
}
*/
